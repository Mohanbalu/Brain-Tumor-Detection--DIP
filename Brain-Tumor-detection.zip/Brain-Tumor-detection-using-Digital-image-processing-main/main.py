import warnings
warnings.filterwarnings('ignore')
import tensorflow as tf
from tensorflow import keras
from keras.applications.vgg16 import preprocess_input
import numpy as np
from tensorflow.keras.preprocessing import image
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QFileDialog, QMessageBox
from tensorflow.keras.models import load_model

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(750, 650)
        MainWindow.setStyleSheet("background-color: #f0f0f0;")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(0, 0, 750, 650))
        self.frame.setStyleSheet("background-color: #035874; border-radius: 10px;")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")

        self.label = QtWidgets.QLabel(self.frame)
        self.label.setGeometry(QtCore.QRect(90, 50, 570, 320))
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setText("Image Preview")
        self.label.setStyleSheet("color: white; font-size: 18px;")
        self.label.setObjectName("label")

        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setGeometry(QtCore.QRect(80, 430, 591, 41))
        font = QtGui.QFont()
        font.setPointSize(24)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setStyleSheet("color: white;")
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setText("MRI Brain Tumor Detection")
        self.label_2.setObjectName("label_2")

        self.pushButton = QtWidgets.QPushButton(self.frame)
        self.pushButton.setGeometry(QtCore.QRect(50, 530, 220, 40))
        self.pushButton.setText("Upload Image")
        self.pushButton.setStyleSheet("""
            QPushButton {
                border-radius: 15px;
                background-color: #DF582C;
                color: white;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #7D93E0;
            }
        """)
        self.pushButton.setObjectName("pushButton")
        
        self.pushButton_2 = QtWidgets.QPushButton(self.frame)
        self.pushButton_2.setGeometry(QtCore.QRect(480, 530, 220, 40))
        self.pushButton_2.setText("Predict Result")
        self.pushButton_2.setStyleSheet("""
            QPushButton {
                border-radius: 15px;
                background-color: #DF582C;
                color: white;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #7D93E0;
            }
        """)
        self.pushButton_2.setEnabled(False)
        self.pushButton_2.setObjectName("pushButton_2")

        self.loading_label = QtWidgets.QLabel(self.frame)
        self.loading_label.setGeometry(QtCore.QRect(250, 380, 250, 30))
        self.loading_label.setStyleSheet("color: white; font-size: 16px;")
        self.loading_label.setAlignment(QtCore.Qt.AlignCenter)
        self.loading_label.setText("Loading, please wait...")
        self.loading_label.setVisible(False)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("patient.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)

        MainWindow.setCentralWidget(self.centralwidget)
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.pushButton.clicked.connect(self.upload_image)
        self.pushButton_2.clicked.connect(self.predict_result)

        self.model = None
        self.image_path = None
        self.result = None

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Brain Tumor Detection"))
        self.pushButton.setText(_translate("MainWindow", "Upload Image"))
        self.pushButton_2.setText(_translate("MainWindow", "Predict Result"))

    def upload_image(self):
        filename, _ = QFileDialog.getOpenFileName(filter="Image Files (*.png *.jpg *.jpeg)")
        if filename:
            self.image_path = filename
            self.update_image_display(filename)
            self.pushButton_2.setEnabled(True)

            if self.model is None:
                self.load_model()

    def update_image_display(self, path):
        img = QtGui.QImage(path)
        pixmap = QtGui.QPixmap.fromImage(img)
        self.label.setPixmap(pixmap.scaled(570, 320, QtCore.Qt.KeepAspectRatio))

    def load_model(self):
        try:
            self.model = load_model('saved_model/project_model')
            print("Model loaded successfully.")
        except Exception as e:
            self.show_error_message("Error", f"Failed to load the model: {e}")

    def predict_result(self):
        if not self.image_path:
            self.show_error_message("No Image", "Please upload an image before prediction.")
            return

        if self.model is None:
            self.show_error_message("Model Not Loaded", "Please wait, the model is not loaded yet.")
            return

        self.loading_label.setVisible(True)

        try:
            img_file = image.load_img(self.image_path, target_size=(240, 240))
            x = image.img_to_array(img_file)
            x = np.expand_dims(x, axis=0)
            img_data = preprocess_input(x.astype('float32'))

            classes = self.model.predict(img_data)
            self.result = classes.tolist()

            self.loading_label.setVisible(False)

            self.show_prediction_result(self.result)

        except Exception as e:
            self.loading_label.setVisible(False)
            self.show_error_message("Prediction Error", f"Error during prediction: {e}")

    def show_prediction_result(self, result):
        if result[0][0] > 0.5:
            self.label_2.setText("Prediction: Normal")
        else:
            self.label_2.setText("Prediction: Brain Tumor Detected")

    def show_error_message(self, title, message):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Critical)
        msg.setWindowTitle(title)
        msg.setText(message)
        msg.exec_()


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())